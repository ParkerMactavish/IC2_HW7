File List:
	GeneralPlayer.h/.cpp
	OrcPlayer.h/.cpp
	MagicianPlayer.h/.cpp
	KnightPlayer.h/.cpp
	main.cpp	
	README.txt

Description:
	The four .h and .cpp are requested in the homework, and main.cpp is my own testbench to check whether the classes are writen correctly; I just attached it with hope of making your work easier.